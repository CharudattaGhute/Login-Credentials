import logo from "./logo.svg";
import "./App.css";
import LoginSignup from "./Components/Login-signup/LoginSignup";

function App() {
  return (
    <div>
      <LoginSignup />
    </div>
  );
}

export default App;
